package org.techtown.androidteamproject;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class signupActivity extends AppCompatActivity implements View.OnClickListener {
    private EditText mEmailText,mPasswordText;
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activitysignup);
        mEmailText=findViewById(R.id.sign_email);
        mPasswordText=findViewById(R.id.sign_password);
        findViewById(R.id.sign_success).setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {

    }
}
